package integration;

import model.PassoOrdenacao;

public class OpenGLRenderBridge implements RenderBridge {
    private MotorGrafico motor;

    public OpenGLRenderBridge(MotorGrafico motor) {
        if (motor == null) {
            throw new IllegalArgumentException("O motor grafico nao pode ser nulo.");
        }
        this.motor = motor;
    }

    public void renderizar(PassoOrdenacao passo) {
        if (passo == null) {
            throw new IllegalArgumentException("O passo de ordenacao nao pode ser nulo.");
        }

        int[] vetor = passo.getVetor();
        motor.renderizarPasso(
                vetor,
                vetor.length,
                passo.getIndiceA(),
                passo.getIndiceB(),
                passo.getTipo().getCodigo());
    }
}

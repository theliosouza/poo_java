package integration;

import model.PassoOrdenacao;

public interface RenderBridge {
    void renderizar(PassoOrdenacao passo);
}

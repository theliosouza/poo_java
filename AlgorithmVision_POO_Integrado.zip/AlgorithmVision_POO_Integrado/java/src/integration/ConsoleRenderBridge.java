package integration;

import model.PassoOrdenacao;

public class ConsoleRenderBridge implements RenderBridge {
    public void renderizar(PassoOrdenacao passo) {
        int[] vetor = passo.getVetor();
        String texto = "";

        for (int i = 0; i < vetor.length; i++) {
            texto += vetor[i];
            if (i < vetor.length - 1) {
                texto += " ";
            }
        }

        System.out.println("[" + passo.getTipo() + "] " + texto
                + " | A=" + passo.getIndiceA()
                + " | B=" + passo.getIndiceB()
                + " | " + passo.getDescricao());
    }
}

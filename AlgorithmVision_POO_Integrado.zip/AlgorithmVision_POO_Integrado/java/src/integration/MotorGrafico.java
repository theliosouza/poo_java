package integration;

public class MotorGrafico {
    static {
        System.loadLibrary("motor");
    }

    public native void iniciar();

    public native void renderizarPasso(int[] vetor, int tamanho, int indiceA, int indiceB, int tipoPasso);

    public native void finalizar();
}

package sorting;

import java.util.ArrayList;
import java.util.List;
import model.PassoOrdenacao;
import model.TipoPasso;

public abstract class OrdenacaoBase implements AlgoritmoOrdenacao {
    protected int[] validarECopiar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor nao pode ser nulo.");
        }
        if (vetor.length == 0) {
            throw new IllegalArgumentException("O vetor nao pode estar vazio.");
        }

        int[] copia = new int[vetor.length];
        for (int i = 0; i < vetor.length; i++) {
            copia[i] = vetor[i];
        }
        return copia;
    }

    protected List<PassoOrdenacao> criarListaComInicio(int[] vetor, String nome) {
        List<PassoOrdenacao> passos = new ArrayList<PassoOrdenacao>();
        passos.add(new PassoOrdenacao(vetor, -1, -1, TipoPasso.INICIO, "Inicio do " + nome));
        return passos;
    }

    protected void adicionarFinal(List<PassoOrdenacao> passos, int[] vetor, String nome) {
        passos.add(new PassoOrdenacao(vetor, -1, -1, TipoPasso.FINALIZADO, nome + " finalizado"));
    }
}

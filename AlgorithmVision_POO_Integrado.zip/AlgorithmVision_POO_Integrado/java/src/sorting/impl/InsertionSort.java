package sorting.impl;

import java.util.List;
import model.PassoOrdenacao;
import model.TipoPasso;
import sorting.OrdenacaoBase;

public class InsertionSort extends OrdenacaoBase {
    public String getNome() {
        return "Insertion Sort";
    }

    public List<PassoOrdenacao> gerarPassos(int[] vetorOriginal) {
        int[] vetor = validarECopiar(vetorOriginal);
        List<PassoOrdenacao> passos = criarListaComInicio(vetor, getNome());

        for (int i = 1; i < vetor.length; i++) {
            int chave = vetor[i];
            int j = i - 1;

            passos.add(new PassoOrdenacao(vetor, i, j, TipoPasso.MOVER,
                    "Selecionou o elemento da posicao " + i + " para inserir"));

            while (j >= 0 && vetor[j] > chave) {
                passos.add(new PassoOrdenacao(vetor, j, j + 1, TipoPasso.COMPARAR,
                        "Comparando para deslocar elemento"));
                vetor[j + 1] = vetor[j];
                passos.add(new PassoOrdenacao(vetor, j, j + 1, TipoPasso.MOVER,
                        "Deslocou o elemento para a direita"));
                j--;
            }

            vetor[j + 1] = chave;
            passos.add(new PassoOrdenacao(vetor, j + 1, i, TipoPasso.MOVER,
                    "Inseriu a chave na posicao correta"));
        }

        adicionarFinal(passos, vetor, getNome());
        return passos;
    }
}

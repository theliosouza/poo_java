package sorting.impl;

import java.util.List;
import model.PassoOrdenacao;
import model.TipoPasso;
import sorting.OrdenacaoBase;

public class QuickSort extends OrdenacaoBase {
    public String getNome() {
        return "Quick Sort";
    }

    public List<PassoOrdenacao> gerarPassos(int[] vetorOriginal) {
        int[] vetor = validarECopiar(vetorOriginal);
        List<PassoOrdenacao> passos = criarListaComInicio(vetor, getNome());
        quickSort(vetor, 0, vetor.length - 1, passos);
        adicionarFinal(passos, vetor, getNome());
        return passos;
    }

    private void quickSort(int[] vetor, int inicio, int fim, List<PassoOrdenacao> passos) {
        if (inicio < fim) {
            int pivo = particionar(vetor, inicio, fim, passos);
            quickSort(vetor, inicio, pivo - 1, passos);
            quickSort(vetor, pivo + 1, fim, passos);
        }
    }

    private int particionar(int[] vetor, int inicio, int fim, List<PassoOrdenacao> passos) {
        int pivoValor = vetor[fim];
        int i = inicio - 1;

        passos.add(new PassoOrdenacao(vetor, fim, -1, TipoPasso.PIVO,
                "Pivo escolhido na posicao " + fim));

        for (int j = inicio; j < fim; j++) {
            passos.add(new PassoOrdenacao(vetor, j, fim, TipoPasso.COMPARAR,
                    "Comparando posicao " + j + " com o pivo"));

            if (vetor[j] <= pivoValor) {
                i++;
                int aux = vetor[i];
                vetor[i] = vetor[j];
                vetor[j] = aux;
                passos.add(new PassoOrdenacao(vetor, i, j, TipoPasso.TROCAR,
                        "Trocou elemento menor que o pivo"));
            }
        }

        int aux = vetor[i + 1];
        vetor[i + 1] = vetor[fim];
        vetor[fim] = aux;
        passos.add(new PassoOrdenacao(vetor, i + 1, fim, TipoPasso.TROCAR,
                "Colocou o pivo na posicao correta"));

        return i + 1;
    }
}

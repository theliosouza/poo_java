package sorting.impl;

import java.util.List;
import model.PassoOrdenacao;
import model.TipoPasso;
import sorting.OrdenacaoBase;

public class SelectionSort extends OrdenacaoBase {
    public String getNome() {
        return "Selection Sort";
    }

    public List<PassoOrdenacao> gerarPassos(int[] vetorOriginal) {
        int[] vetor = validarECopiar(vetorOriginal);
        List<PassoOrdenacao> passos = criarListaComInicio(vetor, getNome());

        for (int i = 0; i < vetor.length - 1; i++) {
            int menor = i;

            for (int j = i + 1; j < vetor.length; j++) {
                passos.add(new PassoOrdenacao(vetor, menor, j, TipoPasso.COMPARAR,
                        "Comparando menor atual com a posicao " + j));

                if (vetor[j] < vetor[menor]) {
                    menor = j;
                    passos.add(new PassoOrdenacao(vetor, i, menor, TipoPasso.MOVER,
                            "Novo menor encontrado na posicao " + menor));
                }
            }

            if (menor != i) {
                int aux = vetor[i];
                vetor[i] = vetor[menor];
                vetor[menor] = aux;
                passos.add(new PassoOrdenacao(vetor, i, menor, TipoPasso.TROCAR,
                        "Trocou a posicao " + i + " com o menor encontrado"));
            }
        }

        adicionarFinal(passos, vetor, getNome());
        return passos;
    }
}

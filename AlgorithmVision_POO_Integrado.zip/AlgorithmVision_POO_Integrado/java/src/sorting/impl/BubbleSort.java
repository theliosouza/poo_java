package sorting.impl;

import java.util.List;
import model.PassoOrdenacao;
import model.TipoPasso;
import sorting.OrdenacaoBase;

public class BubbleSort extends OrdenacaoBase {
    public String getNome() {
        return "Bubble Sort";
    }

    public List<PassoOrdenacao> gerarPassos(int[] vetorOriginal) {
        int[] vetor = validarECopiar(vetorOriginal);
        List<PassoOrdenacao> passos = criarListaComInicio(vetor, getNome());

        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = 0; j < vetor.length - i - 1; j++) {
                passos.add(new PassoOrdenacao(vetor, j, j + 1, TipoPasso.COMPARAR,
                        "Comparando posicoes " + j + " e " + (j + 1)));

                if (vetor[j] > vetor[j + 1]) {
                    int aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;
                    passos.add(new PassoOrdenacao(vetor, j, j + 1, TipoPasso.TROCAR,
                            "Trocou os elementos das posicoes " + j + " e " + (j + 1)));
                }
            }
        }

        adicionarFinal(passos, vetor, getNome());
        return passos;
    }
}

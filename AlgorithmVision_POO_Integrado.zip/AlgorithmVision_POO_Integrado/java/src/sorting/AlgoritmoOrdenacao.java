package sorting;

import java.util.List;
import model.PassoOrdenacao;

public interface AlgoritmoOrdenacao {
    String getNome();
    List<PassoOrdenacao> gerarPassos(int[] vetor);
}

package main;

import java.util.InputMismatchException;
import java.util.Scanner;
import controller.OrdenacaoController;
import integration.ConsoleRenderBridge;
import sorting.AlgoritmoOrdenacao;
import sorting.impl.BubbleSort;
import sorting.impl.InsertionSort;
import sorting.impl.QuickSort;
import sorting.impl.SelectionSort;

public class MainConsole {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        try {
            int[] vetor = { 50, 20, 80, 10, 40, 70, 30, 60 };
            AlgoritmoOrdenacao algoritmo = escolherAlgoritmo(entrada);

            OrdenacaoController controller = new OrdenacaoController(new ConsoleRenderBridge(), 300);
            controller.executar(algoritmo, vetor);
        } catch (InputMismatchException erro) {
            System.out.println("Entrada invalida. Digite apenas numeros.");
        } catch (IllegalArgumentException erro) {
            System.out.println("Erro de validacao: " + erro.getMessage());
        } finally {
            entrada.close();
        }
    }

    private static AlgoritmoOrdenacao escolherAlgoritmo(Scanner entrada) {
        System.out.println("Escolha o algoritmo:");
        System.out.println("1 - Bubble Sort");
        System.out.println("2 - Selection Sort");
        System.out.println("3 - Insertion Sort");
        System.out.println("4 - Quick Sort");
        System.out.print("Opcao: ");

        int opcao = entrada.nextInt();

        if (opcao == 1) {
            return new BubbleSort();
        }
        if (opcao == 2) {
            return new SelectionSort();
        }
        if (opcao == 3) {
            return new InsertionSort();
        }
        if (opcao == 4) {
            return new QuickSort();
        }

        throw new IllegalArgumentException("Opcao invalida. Escolha um numero de 1 a 4.");
    }
}

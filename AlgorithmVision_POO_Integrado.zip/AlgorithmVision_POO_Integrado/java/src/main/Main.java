package main;

public class Main {
    public static void main(String[] args) {
        MainOpenGL.main(args);
    }
}

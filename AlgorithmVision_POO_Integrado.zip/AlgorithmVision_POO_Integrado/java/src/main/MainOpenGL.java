package main;

import java.util.InputMismatchException;
import java.util.Scanner;
import controller.OrdenacaoController;
import integration.MotorGrafico;
import integration.OpenGLRenderBridge;
import sorting.AlgoritmoOrdenacao;
import sorting.impl.BubbleSort;
import sorting.impl.InsertionSort;
import sorting.impl.QuickSort;
import sorting.impl.SelectionSort;

public class MainOpenGL {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        MotorGrafico motor = null;

        try {
            motor = new MotorGrafico();
            final MotorGrafico motorThread = motor;

            Thread threadGrafica = new Thread(new Runnable() {
                public void run() {
                    motorThread.iniciar();
                }
            });
            threadGrafica.start();

            // Pequena espera para a janela OpenGL ser criada antes do envio dos passos.
            Thread.sleep(1200);

            int[] vetor = { 50, 20, 80, 10, 40, 70, 30, 60 };
            AlgoritmoOrdenacao algoritmo = escolherAlgoritmo(entrada);

            OrdenacaoController controller = new OrdenacaoController(new OpenGLRenderBridge(motor), 250);
            controller.executar(algoritmo, vetor);

            System.out.println("Ordenacao finalizada. Pressione ENTER para fechar a janela OpenGL.");
            entrada.nextLine();
            entrada.nextLine();
        } catch (UnsatisfiedLinkError erro) {
            System.out.println("Biblioteca nativa nao encontrada. Compile o alvo 'motor' no CMake antes de executar o modo OpenGL.");
            System.out.println("Detalhe: " + erro.getMessage());
        } catch (InterruptedException erro) {
            Thread.currentThread().interrupt();
            System.out.println("Execucao interrompida: " + erro.getMessage());
        } catch (InputMismatchException erro) {
            System.out.println("Entrada invalida. Digite apenas numeros.");
        } catch (IllegalArgumentException erro) {
            System.out.println("Erro de validacao: " + erro.getMessage());
        } finally {
            if (motor != null) {
                try {
                    motor.finalizar();
                } catch (UnsatisfiedLinkError erro) {
                    // Nao faz nada: a biblioteca ainda pode nao existir durante os testes da parte de POO.
                }
            }
            entrada.close();
        }
    }

    private static AlgoritmoOrdenacao escolherAlgoritmo(Scanner entrada) {
        System.out.println("Escolha o algoritmo para renderizar no AlgorithmVision:");
        System.out.println("1 - Bubble Sort");
        System.out.println("2 - Selection Sort");
        System.out.println("3 - Insertion Sort");
        System.out.println("4 - Quick Sort");
        System.out.print("Opcao: ");

        int opcao = entrada.nextInt();

        if (opcao == 1) {
            return new BubbleSort();
        }
        if (opcao == 2) {
            return new SelectionSort();
        }
        if (opcao == 3) {
            return new InsertionSort();
        }
        if (opcao == 4) {
            return new QuickSort();
        }

        throw new IllegalArgumentException("Opcao invalida. Escolha um numero de 1 a 4.");
    }
}

package controller;

import java.util.List;
import integration.RenderBridge;
import model.PassoOrdenacao;
import sorting.AlgoritmoOrdenacao;

public class OrdenacaoController {
    private RenderBridge renderBridge;
    private int intervaloMilissegundos;

    public OrdenacaoController(RenderBridge renderBridge, int intervaloMilissegundos) {
        if (renderBridge == null) {
            throw new IllegalArgumentException("O renderizador nao pode ser nulo.");
        }
        if (intervaloMilissegundos < 0) {
            throw new IllegalArgumentException("O intervalo nao pode ser negativo.");
        }
        this.renderBridge = renderBridge;
        this.intervaloMilissegundos = intervaloMilissegundos;
    }

    public void executar(AlgoritmoOrdenacao algoritmo, int[] vetor) {
        if (algoritmo == null) {
            throw new IllegalArgumentException("O algoritmo nao pode ser nulo.");
        }
        if (vetor == null || vetor.length == 0) {
            throw new IllegalArgumentException("O vetor nao pode ser nulo ou vazio.");
        }

        List<PassoOrdenacao> passos = algoritmo.gerarPassos(vetor);
        for (int i = 0; i < passos.size(); i++) {
            renderBridge.renderizar(passos.get(i));
            esperar();
        }
    }

    private void esperar() {
        try {
            Thread.sleep(intervaloMilissegundos);
        } catch (InterruptedException erro) {
            Thread.currentThread().interrupt();
            System.out.println("Execucao interrompida: " + erro.getMessage());
        }
    }
}

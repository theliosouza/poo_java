package model;

public class PassoOrdenacao {
    private int[] vetor;
    private int indiceA;
    private int indiceB;
    private TipoPasso tipo;
    private String descricao;

    public PassoOrdenacao(int[] vetor, int indiceA, int indiceB, TipoPasso tipo, String descricao) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor do passo nao pode ser nulo.");
        }
        if (tipo == null) {
            throw new IllegalArgumentException("O tipo do passo nao pode ser nulo.");
        }

        this.vetor = copiarVetor(vetor);
        this.indiceA = indiceA;
        this.indiceB = indiceB;
        this.tipo = tipo;
        this.descricao = descricao == null ? "" : descricao;
    }

    private int[] copiarVetor(int[] origem) {
        int[] copia = new int[origem.length];
        for (int i = 0; i < origem.length; i++) {
            copia[i] = origem[i];
        }
        return copia;
    }

    public int[] getVetor() {
        return copiarVetor(vetor);
    }

    public int getIndiceA() {
        return indiceA;
    }

    public int getIndiceB() {
        return indiceB;
    }

    public TipoPasso getTipo() {
        return tipo;
    }

    public String getDescricao() {
        return descricao;
    }
}

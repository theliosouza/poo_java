package model;

public enum TipoPasso {
    INICIO(0),
    COMPARAR(1),
    TROCAR(2),
    MOVER(3),
    PIVO(4),
    FINALIZADO(5);

    private final int codigo;

    TipoPasso(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }
}

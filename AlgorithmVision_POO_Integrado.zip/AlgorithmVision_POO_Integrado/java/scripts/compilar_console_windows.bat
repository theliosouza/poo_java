@echo off
cd /d %~dp0\..
if not exist build mkdir build
javac -d build src\model\*.java src\sorting\*.java src\sorting\impl\*.java src\integration\*.java src\controller\*.java src\main\*.java
java -cp build main.MainConsole

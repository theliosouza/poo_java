@echo off
cd /d %~dp0\..\..
if not exist java\build mkdir java\build
javac -d java\build java\src\model\*.java java\src\sorting\*.java java\src\sorting\impl\*.java java\src\integration\*.java java\src\controller\*.java java\src\main\*.java
java -Djava.library.path=build -cp java\build main.MainOpenGL

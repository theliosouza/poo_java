#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../.."
mkdir -p java/build
javac -d java/build $(find java/src -name "*.java")
java -Djava.library.path=build -cp java/build main.MainOpenGL

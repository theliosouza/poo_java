#ifndef EXTERNAL_SORT_RENDERER_H
#define EXTERNAL_SORT_RENDERER_H

#include "GLLoader.h"
#include "Shader.h"
#include <mutex>
#include <vector>

struct GLFWwindow;

class ExternalSortRenderer {
public:
    ExternalSortRenderer();
    ~ExternalSortRenderer();

    ExternalSortRenderer(const ExternalSortRenderer&) = delete;
    ExternalSortRenderer& operator=(const ExternalSortRenderer&) = delete;

    void run();
    void updateData(const std::vector<int>& values, int indiceA, int indiceB, int tipoPasso);
    void stop();

private:
    std::mutex dataMutex;
    std::vector<int> data;
    int selectedA;
    int selectedB;
    int stepType;
    bool running;
    bool hasData;

    GLFWwindow* window;
    unsigned int vao;
    unsigned int vbo;

    void setupMesh();
    void destroyMesh();
    void render(Shader& shader, int screenWidth, int screenHeight);
    int getVisualStateForIndex(int index, int indiceA, int indiceB, int tipoPasso) const;
};

#endif

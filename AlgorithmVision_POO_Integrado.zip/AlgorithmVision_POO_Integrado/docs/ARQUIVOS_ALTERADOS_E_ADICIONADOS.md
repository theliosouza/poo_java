# Arquivos alterados e adicionados

## Adicionados para a parte POO

```text
java/src/main/Main.java
java/src/main/MainConsole.java
java/src/main/MainOpenGL.java
java/src/model/PassoOrdenacao.java
java/src/model/TipoPasso.java
java/src/sorting/AlgoritmoOrdenacao.java
java/src/sorting/OrdenacaoBase.java
java/src/sorting/impl/BubbleSort.java
java/src/sorting/impl/SelectionSort.java
java/src/sorting/impl/InsertionSort.java
java/src/sorting/impl/QuickSort.java
java/src/controller/OrdenacaoController.java
java/src/integration/RenderBridge.java
java/src/integration/ConsoleRenderBridge.java
java/src/integration/OpenGLRenderBridge.java
java/src/integration/MotorGrafico.java
```

## Adicionados para a integração JNI/CG

```text
headers/integration_MotorGrafico.h
include/ExternalSortRenderer.h
src/jni/MotorJNI.cpp
src/jni/ExternalSortRenderer.cpp
```

## Alterado

```text
CMakeLists.txt
README.md
```

O `CMakeLists.txt` agora cria também a biblioteca nativa `motor`, usada pelo Java.

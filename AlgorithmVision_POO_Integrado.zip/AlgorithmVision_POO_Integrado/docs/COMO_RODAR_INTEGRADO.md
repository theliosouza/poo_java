# Como rodar a versão integrada

## 1. Testar apenas a parte POO no console

Dentro da pasta principal do projeto:

```bash
mkdir -p java/build
javac -d java/build $(find java/src -name "*.java")
java -cp java/build main.MainConsole
```

No Windows, caso o comando `find` não funcione, compile pelo Eclipse ou use:

```bat
mkdir java\build
javac -d java\build java\src\model\*.java java\src\sorting\*.java java\src\sorting\impl\*.java java\src\integration\*.java java\src\controller\*.java java\src\main\*.java
java -cp java\build main.MainConsole
```

Esse modo não usa OpenGL. Ele serve para testar se os algoritmos e o tratamento de exceções estão funcionando.

## 2. Compilar a parte C++/OpenGL com JNI

Requisitos:

- JDK instalado e `JAVA_HOME` configurado;
- CMake;
- compilador C++;
- GLFW;
- GLM;
- OpenGL;
- GLEW ou GLAD.

Linux:

```bash
mkdir build
cd build
cmake .. -DALGORITHM_VISION_BUILD_JNI=ON
make
```

Windows com CMake:

```bat
mkdir build
cd build
cmake .. -DALGORITHM_VISION_BUILD_JNI=ON
cmake --build .
```

O alvo novo é a biblioteca nativa:

```text
motor.dll      no Windows
libmotor.so    no Linux
```

## 3. Rodar Java chamando a janela OpenGL

Execute a partir da pasta principal do projeto, para os shaders serem encontrados em `shaders/`.

Linux:

```bash
javac -d java/build $(find java/src -name "*.java")
java -Djava.library.path=build -cp java/build main.MainOpenGL
```

Windows:

```bat
javac -d java\build java\src\model\*.java java\src\sorting\*.java java\src\sorting\impl\*.java java\src\integration\*.java java\src\controller\*.java java\src\main\*.java
java -Djava.library.path=build -cp java\build main.MainOpenGL
```

## Observação importante

O executável original `AlgorithmVision` continua existindo. Ele é o modo C++ puro do projeto deles.

A execução correta para o projeto interdisciplinar, integrando POO com CG, é pelo Java:

```text
main.MainOpenGL
```

Nesse modo, os algoritmos ficam em Java e o OpenGL fica responsável apenas por desenhar os passos recebidos.

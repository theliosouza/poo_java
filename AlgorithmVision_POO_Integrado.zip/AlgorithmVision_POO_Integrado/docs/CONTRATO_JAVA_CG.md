# Contrato de Integração Java POO + AlgorithmVision CG

Este contrato define o ponto de ligação entre a parte de Programação Orientada a Objetos e a parte de Computação Gráfica.

## Responsabilidade da POO

A parte Java/POO:

- modela os algoritmos de ordenação;
- gera os passos da execução;
- trata entradas inválidas com exceções;
- envia para a CG apenas os dados necessários para renderização.

Algoritmos implementados em Java:

1. Bubble Sort
2. Selection Sort
3. Insertion Sort
4. Quick Sort

## Responsabilidade da CG

A parte C++/OpenGL:

- cria a janela gráfica;
- recebe os dados enviados pelo Java via JNI;
- renderiza as barras;
- destaca comparação, troca, movimentação, pivô e finalização.

## Classe Java de integração

Arquivo:

```text
java/src/integration/MotorGrafico.java
```

Contrato nativo:

```java
public native void iniciar();

public native void renderizarPasso(
    int[] vetor,
    int tamanho,
    int indiceA,
    int indiceB,
    int tipoPasso
);

public native void finalizar();
```

## Assinaturas C++ JNI

Arquivo:

```text
src/jni/MotorJNI.cpp
```

Funções:

```cpp
JNIEXPORT void JNICALL Java_integration_MotorGrafico_iniciar(JNIEnv*, jobject);

JNIEXPORT void JNICALL Java_integration_MotorGrafico_renderizarPasso(
    JNIEnv* env,
    jobject obj,
    jintArray vetorJava,
    jint tamanho,
    jint indiceA,
    jint indiceB,
    jint tipoPasso
);

JNIEXPORT void JNICALL Java_integration_MotorGrafico_finalizar(JNIEnv*, jobject);
```

## Tipos de passo

Os códigos são definidos em:

```text
java/src/model/TipoPasso.java
```

| Código | Tipo | Uso visual sugerido |
|---:|---|---|
| 0 | INICIO | barras normais |
| 1 | COMPARAR | destacar `indiceA` e `indiceB` em cor de comparação |
| 2 | TROCAR | destacar `indiceA` e `indiceB` em cor de troca |
| 3 | MOVER | destacar deslocamento/inserção |
| 4 | PIVO | destacar pivô do Quick Sort |
| 5 | FINALIZADO | barras em cor de finalização |

## Fluxo

```text
Java POO
  AlgoritmoOrdenacao
        ↓
  PassoOrdenacao
        ↓
  OrdenacaoController
        ↓
  OpenGLRenderBridge
        ↓
  MotorGrafico.renderizarPasso(...)
        ↓ JNI
C++ / OpenGL
  MotorJNI.cpp
        ↓
  ExternalSortRenderer.cpp
        ↓
  Shader + barras do AlgorithmVision
```

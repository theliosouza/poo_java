#include "ExternalSortRenderer.h"

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <algorithm>
#include <iostream>
#include <stdexcept>
#include <thread>

ExternalSortRenderer::ExternalSortRenderer()
    : selectedA(-1), selectedB(-1), stepType(0), running(false), hasData(false),
      window(nullptr), vao(0), vbo(0) {
}

ExternalSortRenderer::~ExternalSortRenderer() {
    stop();
}

void ExternalSortRenderer::run() {
    running = true;

    if (!glfwInit()) {
        std::cerr << "ERRO::GLFW::NAO_INICIOU" << std::endl;
        running = false;
        return;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    window = glfwCreateWindow(1000, 700, "AlgorithmVision - Integracao POO + CG", nullptr, nullptr);
    if (window == nullptr) {
        std::cerr << "ERRO::GLFW::JANELA_NAO_CRIADA" << std::endl;
        glfwTerminate();
        running = false;
        return;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

#if ALGORITHM_VISION_HAS_GLAD
    if (!gladLoadGL(glfwGetProcAddress)) {
        std::cerr << "ERRO::GLAD::INICIALIZACAO_FALHOU" << std::endl;
        glfwDestroyWindow(window);
        glfwTerminate();
        window = nullptr;
        running = false;
        return;
    }
#else
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK) {
        std::cerr << "ERRO::GLEW::INICIALIZACAO_FALHOU: " << glewGetErrorString(err) << std::endl;
        glfwDestroyWindow(window);
        glfwTerminate();
        window = nullptr;
        running = false;
        return;
    }
    glGetError();
#endif

    try {
        Shader shader("shaders/bar.vs", "shaders/bar.fs");
        setupMesh();

        while (running && !glfwWindowShouldClose(window)) {
            glfwPollEvents();

            int width = 0;
            int height = 0;
            glfwGetFramebufferSize(window, &width, &height);

            glViewport(0, 0, width, height);
            glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT);

            render(shader, width, height);

            glfwSwapBuffers(window);
        }
    } catch (const std::exception& erro) {
        std::cerr << "ERRO::MOTOR::" << erro.what() << std::endl;
    }

    destroyMesh();
    if (window != nullptr) {
        glfwDestroyWindow(window);
        window = nullptr;
    }
    glfwTerminate();
    running = false;
}

void ExternalSortRenderer::updateData(const std::vector<int>& values, int indiceA, int indiceB, int tipoPasso) {
    std::lock_guard<std::mutex> lock(dataMutex);
    data = values;
    selectedA = indiceA;
    selectedB = indiceB;
    stepType = tipoPasso;
    hasData = true;
}

void ExternalSortRenderer::stop() {
    running = false;
}

void ExternalSortRenderer::setupMesh() {
    float vertices[] = {
        0.0f, 0.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        1.0f, 1.0f, 0.0f,
        0.0f, 1.0f, 0.0f
    };

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void ExternalSortRenderer::destroyMesh() {
    if (vbo != 0) {
        glDeleteBuffers(1, &vbo);
        vbo = 0;
    }
    if (vao != 0) {
        glDeleteVertexArrays(1, &vao);
        vao = 0;
    }
}

void ExternalSortRenderer::render(Shader& shader, int screenWidth, int screenHeight) {
    std::vector<int> localData;
    int localA;
    int localB;
    int localType;
    bool localHasData;

    {
        std::lock_guard<std::mutex> lock(dataMutex);
        localData = data;
        localA = selectedA;
        localB = selectedB;
        localType = stepType;
        localHasData = hasData;
    }

    if (!localHasData || localData.empty() || screenWidth <= 0 || screenHeight <= 0) {
        return;
    }

    int maiorValor = 1;
    for (int value : localData) {
        maiorValor = std::max(maiorValor, value);
    }

    shader.use();
    glm::mat4 projection = glm::ortho(0.0f, static_cast<float>(screenWidth), 0.0f,
                                      static_cast<float>(screenHeight), -1.0f, 1.0f);
    shader.setMat4("projection", projection);

    glBindVertexArray(vao);

    const float margin = 40.0f;
    const float availableWidth = std::max(1.0f, static_cast<float>(screenWidth) - 2.0f * margin);
    const float availableHeight = std::max(1.0f, static_cast<float>(screenHeight) - 2.0f * margin);
    const float barWidth = availableWidth / static_cast<float>(localData.size());

    for (int i = 0; i < static_cast<int>(localData.size()); i++) {
        float normalizedHeight = static_cast<float>(localData[i]) / static_cast<float>(maiorValor);
        float height = std::max(4.0f, normalizedHeight * availableHeight);
        float x = margin + i * barWidth;

        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(x, margin, 0.0f));
        model = glm::scale(model, glm::vec3(std::max(2.0f, barWidth - 2.0f), height, 1.0f));

        shader.setMat4("model", model);
        shader.setInt("state", getVisualStateForIndex(i, localA, localB, localType));
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    }

    glBindVertexArray(0);
}

int ExternalSortRenderer::getVisualStateForIndex(int index, int indiceA, int indiceB, int tipoPasso) const {
    // Os valores abaixo seguem o enum model.TipoPasso do Java.
    const int INICIO = 0;
    const int COMPARAR = 1;
    const int TROCAR = 2;
    const int MOVER = 3;
    const int PIVO = 4;
    const int FINALIZADO = 5;

    if (tipoPasso == FINALIZADO) {
        return 5;
    }

    if (tipoPasso == COMPARAR && (index == indiceA || index == indiceB)) {
        return 1;
    }

    if ((tipoPasso == TROCAR || tipoPasso == MOVER) && (index == indiceA || index == indiceB)) {
        return 2;
    }

    if (tipoPasso == PIVO && index == indiceA) {
        return 3;
    }

    if (tipoPasso == INICIO) {
        return 0;
    }

    return 0;
}

#include "integration_MotorGrafico.h"
#include "ExternalSortRenderer.h"

#include <algorithm>
#include <iostream>
#include <vector>

static ExternalSortRenderer gRenderer;

JNIEXPORT void JNICALL Java_integration_MotorGrafico_iniciar(JNIEnv*, jobject) {
    gRenderer.run();
}

JNIEXPORT void JNICALL Java_integration_MotorGrafico_renderizarPasso
  (JNIEnv* env, jobject, jintArray vetorJava, jint tamanho, jint indiceA, jint indiceB, jint tipoPasso) {

    if (env == nullptr || vetorJava == nullptr || tamanho <= 0) {
        return;
    }

    jsize realLength = env->GetArrayLength(vetorJava);
    int quantidade = std::min(static_cast<int>(realLength), static_cast<int>(tamanho));
    if (quantidade <= 0) {
        return;
    }

    std::vector<int> vetor(quantidade);
    env->GetIntArrayRegion(vetorJava, 0, quantidade, vetor.data());

    gRenderer.updateData(vetor, static_cast<int>(indiceA), static_cast<int>(indiceB), static_cast<int>(tipoPasso));
}

JNIEXPORT void JNICALL Java_integration_MotorGrafico_finalizar(JNIEnv*, jobject) {
    gRenderer.stop();
}
